@extends('backend.index')


@section('content')

<h1>Admin panel</h1>

@endsection

@section('footer')

@endsection