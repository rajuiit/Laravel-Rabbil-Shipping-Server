<div class="footer" >
<div class="container">
    <div class="row " >
        <div class="col-md-3 contact_inf">
            <h1>CONTACT US</h1>
            <div class="contact"><i class="fa fa-map-marker" aria-hidden="true"></i><a href="">ProSoft & EasyTech</a></div>
            <div class="contact"><i class="fa fa-mobile" aria-hidden="true"></i><a href=""></a></div>
            <div class="contact"><i class="fa fa-envelope-o" aria-hidden="true"></i><a href=""></a></div>



        </div>
        <div class="col-md-3 contact_inf">
            <h1>CUSTOMER SERVICE</h1>
            <div>
                <ul>
                    <li><a href="">My account</a></li>
                    <li><a href="">Wishlist</a></li>
                    <li><a href="">My cart</a></li>
                    <li><a href="">checkout</a></li>
                    <li><a href="">Login</a></li>
                </ul>
            </div>

        </div>
        <div class="col-md-3 contact_inf" >
            <h1>CORPORATION</h1>
            <div>
                <ul>
                    <li><a href="">My account</a></li>
                    <li><a href="">Wishlist</a></li>
                    <li><a href="">My cart</a></li>
                    <li><a href="">checkout</a></li>
                    <li><a href="">Login</a></li>
                </ul>
            </div>

        </div>
        <div class="col-md-3 contact_inf"  >
            <h1>WHY CHOOSE US</h1>
            <div>
                <ul>
                    <li><a href="">My account</a></li>
                    <li><a href="">Wishlist</a></li>
                    <li><a href="">My cart</a></li>
                    <li><a href="">checkout</a></li>
                    <li><a href="">Login</a></li>
                </ul>
            </div>

        </div>

    </div>


</div>

</div>



{{-- js --}}

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" ></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" ></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js" ></script>